<?php 

namespace speed;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\scheduler\PluginTask;
use pocketmine\Plugin;

class Funcion extends PluginTask {

	public function __construct($plugin){

		$this->plugin = $plugin;

		parent::__construct($plugin); 

	}
	
	public function onRun($tick){
	  foreach($this->getOwner()->getServer()->getOnlinePlayers() as $players){
	    $player = $players;
	    $players->setNameTag($p->getName() . "\n" . ($player->getHealth() / $player->getMaxHealth() * 100)."§c%");
	  }
	}
}